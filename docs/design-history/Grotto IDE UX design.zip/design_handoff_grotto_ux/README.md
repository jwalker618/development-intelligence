# Handoff: Grotto — mobile + desktop UX redesign

## Overview

**Grotto** is a mobile-first (and desktop / iPad) web IDE for **agent-driven vibe-coding**: you
direct Claude Code agents running in persistent cloud shells, from your phone or laptop. This
handoff covers a full visual + interaction redesign of the existing MVP (`apps/grotto` in
`jwalker618/generate-web`), elevating it per **`apps/grotto/DESIGN.md`** (the canonical UX spec —
read it alongside this doc; its **CONTRACT** items are fixed) and adding one major reframe:

> **Grotto is a command center for many concurrent agents across repos.** The primary job is
> **triage — "which of my running agents needs me now" — and fast switching between them**, not
> driving a single shell. Multi-**session** for one user (not teams — stays inside DESIGN.md's
> non-goals; promotes the roadmapped "multi-session switcher" to core).

Everything keeps DESIGN.md's behavior contracts: the Agent terminal stays mounted, sync is one
tap, reset is confirm-gated, auto-commit messages are deterministic, Preview ports are entered
manually, the caveman badge mirrors flag files, and the composer stays a native text input.

## About the design files

The bundled file **`grotto-designs.html`** (and its source `grotto-designs.dc.html`) is a **design
reference** — an interactive HTML prototype showing intended **look and behavior**. It is **not
production code to copy**. The task is to **recreate these designs in the target codebase's
environment**:

- `apps/grotto` is a **React 19 + Vite PWA in TypeScript**, with an **xterm.js** terminal over a
  **WebSocket PTY**. Rebuild the designs as React components there — upgrading/replacing
  `src/components/*` and `src/styles.css`.
- The **server + client API contracts are fixed** (`src/api.ts`, `server/*`). Wire the new UI to
  the **existing endpoints**; do not change request/response shapes without cause. One capability
  the designs need that the current server does *not* expose is flagged under **Open questions**.
- Styling in the prototype is inline for streaming reasons. In the app, use whatever the codebase
  prefers (CSS modules / the existing `styles.css` conventions / Tailwind if introduced). The
  **token values below are the source of truth**, not the delivery mechanism.

## Fidelity

**High-fidelity** for everything shown in the design file — final colours, typography, spacing,
radii, motion, and interactions. Recreate pixel-accurately using the token values in this doc.

Coverage is **not 100%** of DESIGN.md yet. Mocked hi-fi vs. build-to-spec:

| Area | Status | Reference |
|---|---|---|
| Login | ✅ hi-fi | option `1c` (dark); apply light per `3a` |
| Home → **Sessions control room** (concurrency) | ✅ hi-fi | `4a` |
| Agent (hero) — dark + light | ✅ hi-fi | `2a` (dark), `3a` (light) |
| Approval surfacing | ✅ hi-fi | `2a` phone 2, `4c` (desktop bar) |
| Composer **@-mention** + path chips | ✅ hi-fi | `3b`, `3c` |
| **File review** + line-range add | ✅ hi-fi | `3b` phone 2, `3c` |
| Session **switcher** + cross-session "needs you" | ✅ hi-fi | `4b` |
| Desktop workbench (two-pane) | ✅ hi-fi | `2b` |
| Desktop **command center** (sessions rail) | ✅ hi-fi | `4c` |
| Light mode (chrome + dark terminal) | ✅ hi-fi | `3a`, `3c` |
| **Git tab** | ⛏ build to spec | DESIGN.md §3.5 + tokens below |
| **Preview tab** | ⛏ build to spec | DESIGN.md §3.7 + tokens below |
| **Files browse/manage** (listing, upload, create, ⋯) | ⛏ build to spec | DESIGN.md §3.4 (file *review* + @-mention are mocked) |

> Earlier exploration options `1a` / `1b` / `1c` and `2b`'s Files-pane variant are **direction
> studies** — the **chosen direction is the amalgam**: `2a`/`2b` structure, `3a` light, `3b`/`3c`
> file-reference, `4a`/`4b`/`4c` concurrency. Build to those.

---

## Design tokens

Two themes. **Dark ("cave") is default/primary.** Light ("daylight") is a user toggle. Crucially,
**in light mode the terminal surface stays dark** — a "cave-mouth" inset (terminals read better
dark, per DESIGN.md). Font + icon systems are shared across themes.

### Colour — Dark (cave)

| Token | Hex | Role |
|---|---|---|
| `bg` | `#12100e` | App background (warm near-black) |
| `bg-cave` (gradient) | `radial-gradient(130% 58% at 50% 120%, rgba(249,115,22,.12), transparent 62%), linear-gradient(180deg,#12100e,#17120e)` | Immersive Agent/session bg |
| `panel` | `#1c1917` | Bars, cards, docks |
| `panel-2` | `#292524` | Raised controls, secondary buttons |
| `well` | `#100e0c` | Input wells, terminal bg |
| `panel-dim` | `#161311` | Idle/tucked surfaces |
| `border` | `#3b352f` | Hairlines |
| `border-dim` | `#241f1b` | Fainter dividers |
| `border-strong` | `#4a4038` | Input borders |
| `text` | `#e7e5e4` | Primary text |
| `muted` | `#a8a29e` | Secondary text |
| `faint` | `#6b645d` | Meta / terminal dim |
| `fainter` | `#4a4038` | Line numbers, disabled |
| `accent` | `#f97316` | THE orange — actions, brand, pins, cursor, "needs you" |
| `accent-bright` | `#fb923c` | Peak sparkline / highlights |
| `accent-mid` | `#c2531f` | Sparkline mids |
| `accent-dim` | `#9a3412` | Outlined-accent borders, pressed |
| `accent-link` | `#f9a066` | Text links |
| `accent-soft` | `rgba(249,115,22, .09–.16)` | Tinted accent fills (cards, chips, active tabs) |
| `ok` | `#22c55e` | Terminal additions, live pulse |
| `ok-check` | `#1f8a5b` | Success checks ("clean", "in prompt") |
| `warn` | `#b47312` | Git modified status code (`M`) |
| `danger` | `#ef4444` | Destructive / reject |
| `danger-border` | `#7a2626` | Reject button outline |
| `code-string` | `#63b784` | Editor string literals (on dark) |

### Colour — Light (daylight)

| Token | Hex | Role |
|---|---|---|
| `canvas` | `#f4efe5` | App background (warm paper) |
| `surface` | `#ffffff` | Cards |
| `surface-elev` | `#fbf8f2` | Top bars, tinted strips |
| `raised` | `#efe7d8` | Raised controls, keys, tab track |
| `well` | `#faf6ee` / `#fffdf8` | Input wells / editor bg |
| `border` | `#e4dccc` | Hairlines |
| `border-strong` | `#d3c8b4` | Input borders |
| `ink` | `#2a211b` | Primary text |
| `muted` | `#7d7264` | Secondary text |
| `faint` | `#a89e8f` | Meta |
| `fainter` | `#bfb5a3` | Line numbers |
| `accent` | `#f97316` | Fills, CTAs, cursor |
| `accent-ink` | `#bd5417` | Accent **text** (contrast on paper) |
| `accent-deep` | `#e2620f` | Peak sparkline |
| `accent-soft` | `#fbe9dd` | Tinted accent fills |
| `ok` | `#1f8a5b` | Success / live |
| `code-string` | `#1f7a52` | Editor strings (on light) |
| **terminal (both themes)** | `#17130f` bg, `#e7e5e4` text, `#f97316` cursor | The terminal stays dark in light mode |

### Typography

- **Families:** `'IBM Plex Sans'` (UI + display), `'IBM Plex Mono'` (terminal, code, file paths,
  numbers, badges, status codes). Load from Google Fonts:
  `https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600&display=swap`
  (matches the platform's own `globals.css`).
- **`font-variant-numeric: tabular-nums`** on every figure (savings, counts, token estimates,
  ahead/behind, times, ports, clock).
- **Eyebrow** (recurring signature): `9–10.5px / 600 / uppercase / letter-spacing .12–.14em`, in
  `muted` (or `accent` for "needs you" / active).
- **Hero number:** IBM Plex Mono `700`, `19–30px`, `tabular-nums`, `letter-spacing -.02em`
  (e.g. `12.4k` savings).
- **Body:** 13–15px Sans. **Terminal / code:** 12–12.5px Mono, line-height 1.7–1.8.
- **Buttons:** 13–16px / 600. **Tab labels:** 10–12.5px / 600. **Chips / paths:** 11.5–12px Mono.
- Sentence case everywhere; the only uppercase is the eyebrow. No emoji, ever.

### Spacing, radius, elevation, motion

- **Spacing:** ~8px rhythm. Card padding 12–16px; screen gutters 12–18px; element gaps 6–14px.
- **Radius:** phone screen `36px`; cards `14px`; docks `16–22px`; buttons/inputs `10–14px`;
  chips / pills / FAB `999px`; nav tiles & keys `8–12px`; device bezel `46px`.
- **Elevation:** quiet — **hairlines do most separation**. Real shadow only for things that float:
  - Composer dock: `0 -2px 26px -8px rgba(249,115,22,.28), 0 10px 24px -12px rgba(0,0,0,.6)` +
    `border-top: 2px solid #f97316` (light) or `1.5px rgba(249,115,22,.32)` (dark).
  - Approval card: `0 -6px 34px -8px rgba(249,115,22,.4), 0 0 0 4px rgba(249,115,22,.06)`.
  - FAB / send / primary: `0 4px 14–16px -3px rgba(249,115,22,.55)`.
  - Bottom sheet: `0 -12px 34px -10px rgba(0,0,0,.7)`.
  - Live dots & cursor: `box-shadow: 0 0 6–10px <accent|ok>` (a glow, not a drop shadow).
- **Motion:** no bounce, no press-shrink, no decorative blur beyond the terminal firelight glow.
  - Sheets / cards / pills entering: **300–340ms `cubic-bezier(0.2,0.7,0.2,1)`** (translateY 14px
    + fade). This is the "grain / pane-in" family from the platform.
  - Colour/state changes: ~180ms fades.
  - Terminal cursor: 1.1s step-end blink. Live "running" pulses: 1.3–3s ease-in-out opacity.

### Iconography

**Lucide**, 2px stroke, `currentColor`, sized 11–22px. Names used: `chevron-left/right/down`,
`terminal`, `folder`, `folder-plus`, `file`, `file-plus`, `git-branch`, `eye`, `pin`, `check`,
`check-check`, `x`, `plus`, `arrow-up` (send), `arrow-right`, `refresh-cw`, `upload`, `settings`,
`sun`, `moon`, `search`, `lock`, `alert-triangle` (approval), `message-circle-question` (ask/query),
`copy`, `keyboard`, and a **custom "pickaxe"** for the savings/`⛏` motif. No emoji, no other icon
fonts. **Brand mark** = the cave-arch logo (`apps/grotto/public/icon.svg`): outer orange arch,
inner cut-out in the background colour.

---

## Information architecture (with the concurrency reframe)

```
Login
  └─▶ Sessions control room  ← the new "Home" (4a): triage all concurrent agents
        ├─ New session (repo/branch picker; long clone tolerated)
        ├─ "Needs you" triage  ── tap ▶ jumps into that session's approval
        └─▶ Session (2a) ──┬── Agent (default) · Files · Git · Preview  (bottom tab dock)
                 ▲          ├── @-mention composer · file review (3b)
                 │          └── switch to another live session (4b switcher; tap repo·branch ⌄)
                 └── cross-session "needs you" banner can pull you to ANY session (4b)

Desktop / iPad (2b / 3c / 4c): same paradigm stretched —
  • Persistent left SESSIONS RAIL (every agent, "needs you" first) + active WORKBENCH (4c)
  • Terminal stays mounted; the picked tab opens as a PANE beside it (2b)
  • Theme toggle → light; go-to-file (⌘K) + file review + scoped "ask" (3c)
```

Navigation axes: **bottom tab dock** switches Agent/Files/Git/Preview within a session (mobile);
on desktop these are a **segmented control** in the workbench top bar and open as a right pane.
**Session switching** is lateral (switcher sheet on mobile, rail on desktop). The terminal is kept
warm for the active session; on switch, the target reconnects and replays ~200 KB scrollback (per
DESIGN.md CONTRACT), so non-active terminals can be lazily mounted.

---

## Screens / views

Each references its option id in `grotto-designs.html` (open it to see the pixels). Copy strings
are exact.

### 1. Login  ·  `1c`  ·  DESIGN.md §3.1
- **Purpose:** paste the server token once. Sets tone — the "cave entrance".
- **Layout:** full-screen, vertically centred column, 30–32px gutters. Atmospheric bg:
  `radial-gradient(120% 75% at 50% 112%, rgba(249,115,22,.2), transparent 58%)` over
  `linear-gradient(180deg,#0f0d0b,#15100c)`; an inset vignette
  (`box-shadow: inset 0 0 120px 40px rgba(8,6,5,.85)`); and a faint **receding cave-arch tunnel**
  (4 nested arch outlines in `accent`, opacity .14→.05, scaled about the bottom centre) behind the
  content.
- **Components:** cave-arch mark 80px with `drop-shadow(0 0 26px rgba(249,115,22,.6))`; wordmark
  "**Grotto**" IBM Plex Sans 700 / 40px / -.02em / `#f4efe5`; helper (muted, 14px/1.6):
  "A cave for vibe-coding. Paste the token printed by the Grotto server."; a password field (lock
  icon + masked dots, mono, radius 14, `border #4a4038`, well bg); primary CTA "**Enter the cave**"
  (accent fill, `#12100e` text, arrow-right, radius 14, 15px shadow). Enter submits when non-empty.
- **States:** empty (CTA disabled) → filled → submit. A 401 anywhere in the app returns here
  ("Re-enter token"). **CONTRACT:** token is the only credential.

### 2. Sessions control room (Home)  ·  `4a`  ·  DESIGN.md §3.2 + §7.5
- **Purpose:** triage every concurrent agent in <5s; start/resume sessions. **This replaces the
  single-session Home.**
- **Layout:** `100dvh` column. Brand bar (cave mark + "Grotto" 700/18 + settings gear). Scrolling
  list with a bottom **"New session" FAB** (accent pill, bottom-right, over a bg-fade gradient).
- **Components, top→bottom:**
  - **Triage summary card** (`accent-soft` bg, accent border, radius 14): big Mono `1` (30px,
    accent) + "**agent needs you**" + submeta "3 running · 2 idle · 6 total" + chevron. Tap →
    scrolls/filters to "Needs you".
  - **Eyebrow section headers:** "Needs you", "Running · N", "Idle · N".
  - **Needs-you card:** `accent-soft` fill, accent border, **3px accent left bar**. Row 1: repo
    (600/14) + branch (Mono, muted) … right: pulsing accent dot + "NEEDS YOU" (Mono 10, accent).
    Row 2: alert-triangle + "approve `Bash(git push)`". Full-width "**Review →**" button (accent
    fill). Tap → opens that session at the approval.
  - **Running cards** (`panel`, hairline): live green dot (glow + `glowpulse`) + repo (600) …
    right: `⛏ 8.2k` (Mono, accent, tabular). Row 2: `branch · last terminal line` (Mono, faint;
    additions in `ok`). Example lines: "pricing-v2 · edit rating.py +40", "main · run pytest · 34
    pass". Tap → opens the session (Agent tab).
  - **Idle cards** (`panel-dim`, dimmer): hollow-ring dot (or `ok-check` check for clean/synced) +
    repo (muted) + branch … right: "pushed · 2h" / "clean". A `✕` on a session destroys the
    workspace (**confirm-gated** — DESIGN.md notes the MVP lacks this; add a sheet).
- **Data:** `api.sessions()` returns `SessionInfo[]` (`repo, branch, ptyLive, setup`). Status
  buckets: **needs-you** (see Open questions), **running** (ptyLive + recent output), **idle**
  (ptyLive false / done), **setup** (`setup: "running"|"failed"` → amber pulse / "setup failed").
  Savings per session from the caveman badge source.
- **New session:** FAB → repo picker (configured list `api.config().repos` + free `owner/repo`),
  optional branch ("created if missing"), primary CTA. **Clone takes 5–60s** — show an
  indeterminate progress moment ("Cloning generate-web…" + a shimmer bar), never a fake %; the
  user can leave and return (see `1a`'s Home for the cloning treatment to reuse).

### 3. Agent (hero)  ·  dark `2a`, light `3a`  ·  DESIGN.md §3.3
- **Purpose:** watch the agent work; steer it. 80% of usage.
- **Layout (top→bottom), `100dvh` column:** status bar → **top bar** (back ‹ · `repo·branch`
  centred, truncating, with a **`⌄`** that opens the session switcher · caveman **ULTRA** pill) →
  compact **savings hero** strip → "AGENT WORKBENCH · live" eyebrow rule → **terminal** (fills) →
  collapsed "**Terminal keys**" handle → **floating composer dock** → **floating tab dock**.
- **Terminal:** immersive, `bg-cave`/`well`, IBM Plex Mono 12–12.5px, line-height 1.74; bottom-
  anchored (`justify-content:flex-end`) so newest lines show; a soft **firelight glow**
  (`radial-gradient` accent, blurred, `glowpulse`) behind a block **cursor** (`#f97316`, `0 0 10px`
  glow, 1.1s blink). Content is caveman-compressed (short lines): `● verb file +add −del`, `run …`,
  `✓ N pass`, terse notes ("keys tuck.", "put down rock."). Additions `ok`, deletions `danger`,
  bullets/emphasis `accent`, meta `faint`. **CONTRACT:** on every (re)connect the screen clears and
  ~200 KB scrollback replays, then live resumes; on shell exit print "[shell exited (code) — press
  any key to restart]".
- **Savings hero** (the token-economy brand moment): `accent-soft`/card, pickaxe + Mono `12.4k`
  (accent, hero) + "saved · caveman ultra" + a 6-bar **sparkline** (dim→bright accent). Mirrors the
  caveman flag files (**CONTRACT:** never invents state; ~15s poll).
- **Terminal keys** (tucked; the raw PTY keys are secondary to prompting): a slim handle
  "⌨ Terminal keys — Esc · ^C · ↑↓ · ⏎ ›"; expands to the full key bar
  `Esc Tab ^C ↑ ↓ ← → ⏎ │ ✓1 ✓✓2 ✗3`. The approval group (1=yes, 2=yes/always, 3=no) is an
  accent-outlined connected segment (see DESIGN.md §3.3; sequences in `KeyBar.tsx`).
- **Composer dock** (the hero input — **CONTRACT: native `<textarea>`**; Enter sends, Shift+Enter
  newlines): a floating card, radius 18–20, hairline + accent top-glow. Header: "PROMPT THE AGENT"
  eyebrow (accent) + context readout ("Composer.tsx · ~2.1k ctx", Mono, tabular). **Chips**
  (speed-dial, horizontal scroll): `claude` (filled), `gemini`, `/caveman`, `/caveman ultra`,
  `/caveman-stats`, `/caveman-prune`, `git status` — accent-outlined pills; `claude` filled.
  **Pins/path chips** (see §5). Input well + circular accent **send** (arrow-up). Sending prepends
  pinned files as `@path` mentions.
- **Tab dock:** floating segmented pill, 4 tabs (Agent active = `accent-soft`): Agent (terminal
  glyph), Files (folder), Git (git-branch), Preview (eye). ≥44px targets.
- **Light mode (`3a`):** all chrome → daylight tokens (paper cards, ink text, `accent-ink` for
  accent text); **the terminal stays the dark `#17130f` inset**; a **theme toggle** (sun/moon) sits
  in the top bar next to the badge.

### 4. Approval surfacing  ·  `2a` phone 2 (mobile), `4c` (desktop)  ·  DESIGN.md §3.3 / §7.3
- **Purpose:** answer Claude Code's numbered permission prompt as a first-class approve/reject
  moment (not just typing 1/2/3).
- **Mobile:** the terminal shows the permission dialog; a **glowing approval card** rises (pillup)
  above the composer: alert-triangle + "APPROVAL NEEDED" eyebrow (accent) · "The agent wants to
  run" · a Mono code well (`git push origin main`) · buttons **"Yes, run it"** (full-width accent
  fill) then **"Always"** (accent outline) + **"No"** (danger outline) in a row. Maps to sending
  `1` / `2` / `3` to the PTY.
- **Desktop (`4c`):** a horizontal **approval bar** across the workbench foot: "APPROVE" eyebrow +
  code well + `[Yes] [Always] [✗]`.
- **CONTRACT (principle 2):** do **not** rebuild the agent's diff/approval loop client-side — the
  terminal remains source of truth; these controls only inject the keystroke. Detecting *when* to
  show the card is the heuristic under **Open questions**; outside a dialog the keys just type
  digits (harmless).

### 5. Composer @-mention + path chips  ·  `3b` phone 1, `3c`  ·  DESIGN.md §3.4 (pins)
- **Purpose:** the user's core loop — **reference files (with their paths) in prompts**. Typing
  `@` opens a file search; picked files ride along as `@path` and show as chips with a live token
  estimate.
- **@-autocomplete panel** (floats above the composer, pillup in): header `@` + typed query (e.g.
  "Com", blinking caret) + "ADD FILE" eyebrow; result rows = file icon + **filename** (600) + dim
  **relative path** (Mono) + a `+` (or `✓` check if already added); the top match is `accent-soft`
  highlighted. Fuzzy-matches the checkout. Footer behaviour: ↑↓ move, ⏎ add.
- **Path chips** ("In this prompt" eyebrow + "2 files · ~3.4k ctx"): pills `accent-soft` /
  accent-border, `@` (accent) + **full path** `src/components/Composer.tsx` (Mono) + `✕`. These ARE
  the pins (`SessionView` pins state → composer prepends `@path`). Token estimate ≈ pinned bytes +
  draft length / 4 (`api.stat`).

### 6. File review  ·  `3b` phone 2, `3c`  ·  DESIGN.md §3.4
- **Purpose:** access & **query** a file, then include it — the whole file or a **line range**.
- **Layout:** header (back ‹ · filename 600 + full path Mono muted · copy-path icon) · meta eyebrow
  "TSX · 96 lines · 3.2 KB" + status ("✓ in prompt", `ok-check`) · **code body** with line numbers
  and light syntax colour (keywords `accent`/`accent-ink`, strings `code-string`, comments `faint`,
  numbers `fainter`). **Selecting lines** highlights them (`accent-soft` bg + accent left bar) and
  raises a floating pill "**Add lines 5–9 to prompt**" (accent). Foot action bar: "**Ask about
  this**" (accent outline, message-circle-question) + "**Path**" (copy). Adding → a path chip
  carrying the range (e.g. `@…/Composer.tsx:5-9`).
- **Desktop (`3c`):** right pane with a **"Go to file… ⌘K"** finder at top (quick access across
  the checkout), the reviewable file, the line-range pill, and a foot **scoped query** box "Ask
  about Composer.tsx…" → sends a prompt pre-scoped to the file. **CONTRACT (§3.4):** editor is a
  secondary path (agent edits; humans nudge); don't grow it into a desktop file manager.

### 7. Session switcher + cross-session "needs you"  ·  `4b`  ·  DESIGN.md §7.5 / §7.1
- **Switcher (bottom sheet, pillup in):** triggered by the top-bar `repo·branch ⌄`. Header "Switch
  session · 6 live" + "New" (accent outline). Rows (status dot + repo 600 + `branch · status`):
  **needs-you** first (`accent-soft`, "NEEDS YOU"), then **current** (`panel-2`, "CURRENT"), then
  **running** (green pulse + `⛏` savings), then **idle**. Tap → switch (terminal reconnects +
  replays). A scrim dims the session beneath; Escape/drag dismiss.
- **Cross-session banner:** while in session A, a slim `accent-soft` banner slides from the top:
  pulsing dot + "**loss-intelligence** needs you" + "approve npm publish" + "**Go →**" + dismiss.
  Tap → jumps to that session's approval. This is the in-app form of the **notification** roadmap
  (§7.1); a real push notification lands the same way.

### 8. Desktop workbench (two-pane)  ·  `2b`  ·  DESIGN.md §5 (responsive stretch)
- **Purpose:** the faithful desktop/iPad **stretch** of the mobile paradigm — *not* a separate
  desktop-IDE. The **terminal + composer stay mounted on the left**; the tab you pick opens as a
  **pane on the right**.
- **Layout:** browser chrome → grotto top bar (cave mark · back · `repo·branch` · **tab segmented
  control** with Agent marked always-live (green dot) + the active pane tab · savings pill ·
  settings) → body = **left Agent pane (~52–54%)** (workbench eyebrow + terminal + composer dock) ·
  hairline divider (grip dots) · **right pane** (the active tab). The design shows Files (tree +
  editor); it also hosts Git / Preview / file-review (`3c`).

### 9. Desktop command center (sessions rail)  ·  `4c`  ·  DESIGN.md §7.5
- **Purpose:** monitor **every** agent and jump instantly; approve in place.
- **Layout:** browser chrome → body = **left sessions rail (246px)** + **workbench (fills)**.
- **Rail** (`#0f0d0b`, hairline right): brand (cave mark + "Grotto" + settings) → full-width
  "**New session**" (accent) → eyebrow-grouped rows "Needs you · 1" / "Running · 3" / "Idle · 2".
  Row = status dot (accent glow-pulse / green pulse / hollow / `ok-check` check) + repo (600,
  truncate) + branch (Mono, faint) + optional `⛏` savings. The **needs-you / active** row is
  `accent-soft` with a **3px accent left bar**. Click → loads that session in the workbench.
- **Workbench:** top bar (`repo·branch` + tab segmented control + savings) + Agent terminal +
  (when that session needs you) the **approval bar** (§4). Add a **monitor/grid mode** later to
  tile several terminals (noted, not mocked).

### 10. Files browse/manage  ·  build to spec  ·  DESIGN.md §3.4
Not mocked — build in the chosen vocabulary. **Toolbar:** breadcrumb `root / seg / seg` (accent
crumbs) + `⬆ Upload` · `＋ File` · `＋ Folder` (icon buttons; replace `window.prompt` with proper
sheets). **Listing:** dirs first then files; each row = icon + name + (files) a **pin toggle** (lit
= accent glow) + a `⋯` that expands **Rename / Move** and **Delete** (delete confirms). **Editor**
opens in place (header: back-to-dir · path · pin · Save — disabled until dirty, "Saved" when
clean; body = the syntax-lit review/editor from §6). Uploads land in the current dir (32 MB cap);
honour the **screenshot → pin → prompt** flow (uploading an image offers "pin & prompt about it").
**CONTRACT:** workspace-jailed; secondary to the agent.

### 11. Git  ·  build to spec  ·  DESIGN.md §3.5
Not mocked. **Branch line:** git-branch icon + branch (Mono) + `↑ahead ↓behind` (tabular) + refresh.
**Changes:** one row per file (`status` code + path; `M` = `warn`, `??` = `ok`), tap → **diff
takeover** (full-screen; additions `ok`, deletions `danger`, hunk headers `accent`, context
muted/faint, horizontal scroll). **Sync block:** hero "**⚡ Sync (commit · pull · push)**" (accent
fill, one tap — **CONTRACT**) + message field ("blank = auto-generated", deterministic
`sync: N files — a, b, c` — **CONTRACT**) + secondary `Commit all / Push / Pull`. **Op output:**
quiet Mono block. **History timeline:** last 50 `sha subject when`; current = HEAD (marked,
disabled); tapping a past commit offers **reset workspace to this commit** behind an explicit,
consequence-stating **confirm** (**CONTRACT**). Style HEAD and the consequence unmistakably.

### 12. Preview  ·  build to spec  ·  DESIGN.md §3.7
Not mocked. **Preview bar:** numeric **port** field (remembered per session) + `Load`/`Reload` +
`Open ↗`. **Empty state (instructional):** "Start a dev server in the **Agent** tab (e.g. ask the
agent to run `pnpm dev`), then load its port here." + "Hot reload works — changes refresh this pane
automatically." **Loaded:** full-bleed iframe (white — the previewed app owns its theme); HMR flows
through. **Failure:** a readable, friendly message ("Nothing is listening on 127.0.0.1:5173 — start
a dev server in the Agent tab first"), **not** a raw error page. **CONTRACT:** manual port entry;
proxy reaches only localhost in the session container.

---

## Interactions & behaviour

- **Navigation:** Login → Sessions control room → Session. Within a session: **bottom tab dock**
  (mobile) / **segmented control + right pane** (desktop) switches Agent/Files/Git/Preview; the
  Agent terminal **stays mounted** (socket + scroll preserved) while other tabs show. **Lateral**
  session switching via the switcher (mobile) / rail (desktop).
- **Concurrency triage:** sessions are ranked **needs-you → running → idle**. "Needs you" uses the
  accent as a spotlight (pulsing dot + card + Review CTA); running uses live green pulses + last
  line + savings; idle is quiet. A cross-session banner/notification can pull the user into any
  session.
- **@-mention:** typing `@` in the composer opens the file-search panel; ↑↓ move, ⏎/tap adds a
  `@path` chip; `✕` removes; token estimate updates live. File-review "Add" and line-range "Add
  5–9" inject chips too.
- **Approval:** the approval card/bar injects `1`/`2`/`3` to the PTY; it appears when a permission
  prompt is likely on screen (heuristic — see Open questions) and dismisses on answer.
- **Terminal:** taps focus it (xterm handles its own input) but the composer is the promoted path —
  keep that hierarchy obvious. On (re)connect: clear + replay ~200 KB scrollback, then live. On
  keyboard open (`interactive-widget=resizes-content`) the terminal shrinks and the composer stays
  glued above the keyboard with the latest lines visible.
- **Sync:** one tap = commit (auto/typed msg) → pull/rebase → push; a 422 surfaces git's own
  message (e.g. "rebase conflict — resolve in the Agent tab"). **Reset:** confirm-gated, explains
  lost work + force-push caveat.
- **Animations:** sheets/cards/pills in at 300–340ms `cubic-bezier(0.2,0.7,0.2,1)`; state fades
  ~180ms; cursor blink 1.1s; running pulses 1.3–3s. No bounce / no press-shrink.
- **Empty / loading / error states:** control room empty ("No sessions — start one"), clone
  progress (indeterminate), Files empty ("Empty directory"), Git clean ("Working tree clean"),
  Preview empty/failure (above), and a single **401 → re-enter token** recovery from anywhere.
- **Responsive:** the phone layout is the base; desktop/iPad is its stretch — rail/two-pane appear
  at wide widths, the bottom tab dock becomes a top segmented control, content fills width (uniform
  gutters, no max-width centring). Test every screen with the keyboard open.

## State management

Client state (React), wired to the **existing** `src/api.ts`:
- **Auth token** — `localStorage['grotto-token']`; `Bearer` on every request + WS URL; 401 →
  re-enter.
- **Sessions** — `api.sessions()` (`SessionInfo[]`), polled; derive status buckets
  (needs-you/running/idle/setup) + per-session savings. **Active session** id; **switcher** open
  state.
- **Terminal** — one WebSocket per active session (`termUrl`); keep the active hot, lazily mount
  others on switch (reconnect replays scrollback). `registerSend` bridges composer/keys → PTY.
- **Pins / @-mentions** — per session `localStorage['grotto-pins-<id>']` (string[] of paths, now
  incl. optional `:start-end` ranges); token estimate via `api.stat`.
- **Preview** — per session `localStorage['grotto-preview-port-<id>']`.
- **Caveman badge** — `api.caveman()` (`{mode, savings}`), ~15s poll; drives the badge + savings
  hero. Mirrors flag files only.
- **Theme** — `light | dark` persisted (localStorage); default dark; terminal stays dark in both.
- **Git / Files** — `api.gitStatus/gitLog/gitDiff/gitOp`, `api.files/file/saveFile/mkdir/move/
  deletePath/upload` (all fixed shapes).

## Open questions / dependencies (please resolve before/at build)

1. **"Needs you" detection is the one capability the current server does NOT expose.** The
   triage/switcher/banner depend on knowing a session is **blocked on an approval** (or has
   finished). DESIGN.md principle 2 says *don't invent a client protocol* for the agent loop.
   Options for Code to choose: **(a)** a lightweight **server-side signal** — the PTY layer
   pattern-matches Claude Code's numbered permission prompt / idle-after-output and exposes it on
   `SessionInfo` (recommended; server is Code's domain); or **(b)** a **client heuristic** on
   replayed output (fragile). Everything "needs you" hangs off this — decide early.
2. **Notifications (§7.1):** the cross-session banner is the in-app form; real push (finished runs
   / approvals while backgrounded) needs a permission-ask moment + a service worker + a "jump into
   the Agent tab" landing. Roadmap, but the banner design is ready to reuse.
3. **Projects vs. repos grouping:** the control room groups by **status** then repo. The user works
   across "repos **and** projects" — confirm whether a higher **project** grouping/label is wanted
   (a `project` field on sessions), and the expected **scale** (designed for ~a dozen).
4. **Multi-terminal memory:** how many live terminals to keep mounted vs. resume-on-switch (perf).
5. **Un-mocked tabs:** Git, Preview, and Files-browse are specced above + in DESIGN.md but not
   pixel-mocked — flag if you want them mocked before build.

## Assets

- **Brand mark:** cave-arch logo — `apps/grotto/public/icon.svg` (outer `#f97316` arch, inner
  cut-out in bg colour). Also the PWA icon.
- **Icons:** **Lucide** (already the platform's system; load from its package / the existing
  `Icon` wrapper). The pickaxe/`⛏` savings glyph is custom (2-stroke: handle + arc).
- **Fonts:** IBM Plex Sans + IBM Plex Mono from Google Fonts (URL above) — matches the platform.
  No binaries vendored.
- **No emoji, no other icon fonts, no raster illustrations.** The MVP's emoji (🪨/📁/🌿/👁) are
  replaced by Lucide + the cave-arch mark.

## Files in this package

- **`grotto-designs.html`** — self-contained, openable design reference (all options `1a`–`4c`).
  Pan/zoom canvas; reference each screen by its option id.
- **`grotto-designs.dc.html`** — the source (Design Component) for the same, if you want the
  markup.
- **In the repo (what to modify):** `apps/grotto/DESIGN.md` (canonical spec — read it),
  `apps/grotto/src/App.tsx` (routing → add control room + switcher), `src/components/*`
  (`Home`→control room, `SessionView`, `Terminal`, `Composer`, `KeyBar`, `Files`, `Git`,
  `Preview`, `StatusBar`), `src/styles.css` (token system → both themes). `src/api.ts` +
  `server/*` are the fixed contracts (except the needs-you signal in Open questions #1).
```